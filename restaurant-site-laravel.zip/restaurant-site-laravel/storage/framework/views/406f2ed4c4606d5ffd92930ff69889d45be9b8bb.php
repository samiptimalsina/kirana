  <!-- Preloader Starts -->
  <div class="preloader absolute-center-parent size-full bg-black/50 z-10">
    <div class="absolute-center-child size-10 bg-amber-500 rounded-full m-0 animate-ping origin-top"></div>
  </div>
  <!-- Preloader End --> 
<?php /**PATH /home/rishi/Desktop/restaurant-site-laravel/resources/views/home/partials/preloader.blade.php ENDPATH**/ ?>